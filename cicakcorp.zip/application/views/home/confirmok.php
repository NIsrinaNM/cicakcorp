<?php $this->load->view("home/navigasilogin")?>
<link href="<?php echo base_url()?>assets/css/profileuser.css" rel="stylesheet" type="text/css" media="all">
		<div class="container">
			<div class="row mb40">
    		<div class="chute chute-center text-center">
			<div class="col-md-12 mb5">
				<img height=250px width=250px src="<?php echo base_url()?>assets/image/ok.png"/>
				<div class="demo-grid">
					<h2><strong>Terima kasih telah Melakukan Konfirmasi Pembayaran</strong></h2>
					<p>Barang pesanan anda akan segera kami proses. <br>
						Terima kasih telah mempercayai kami</p>
						<br><br><br>
					<img height=100px width=100px src="<?php echo base_url()."assets/image/logo.png"?>">
					<h4>~Cicak Corp~</h4>
					<h5>Be Creative Mawon</h5>
				</div>
			</div>
			</div>
		    </div>
        </div>
    <div>

<?php $this->load->view("home/footer")?>